﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using upr1.Data;
using upr1.Data.Model;
using Microsoft.EntityFrameworkCore;

namespace upr1.Controller
{
    class ShoesController
    {
        private ShoesContext shoesContext = new ShoesContext();
        /// <summary>
        /// Creating an object from the ShoesContext class. Also defining the methods that will later be used
        /// in the display.cs class so we can use the CRUD operations in the display
        /// </summary>
      
       
        public List<Shipping> GetAllShipping()
        {
            return shoesContext.Shippings.ToList();
        }
        public Shipping GetShippings(int id)
        {
            return shoesContext.Shippings.Find(id);
        }

        public void AddShippings(Shipping shipping)
        {
            shoesContext.Shippings.Add(shipping);
            shoesContext.SaveChanges();
        }
        public void UpdateShippings(Shipping shipping)
        {
            var item = shoesContext.Shippings.Find(shipping.Shipping_id);
            if (item != null)
            {
                shoesContext.Entry(item).CurrentValues.SetValues(shipping);
                shoesContext.SaveChanges();
            }

        }
        public void DeleteShipping(int id)
        {
            var item = shoesContext.Shippings.Find(id);
            if (item != null)
            {
                shoesContext.Shippings.Remove(item);
                shoesContext.SaveChanges();
            }
        }





        public List<Promo> GetAllPromo()
        {
            return shoesContext.Promos.ToList();
        }
        public Promo GetPromos(int id)
        {
            return shoesContext.Promos.Find(id);
        }

        public void AddPromos(Promo promos)
        {
            shoesContext.Promos.Add(promos);
            shoesContext.SaveChanges();
        }
        public void UpdatePromos(Promo promos)
        {
            var item = shoesContext.Promos.Find(promos.Sale_id);
            if (item != null)
            {
                shoesContext.Entry(item).CurrentValues.SetValues(promos);
                shoesContext.SaveChanges();
            }

        }
        public void DeletePromos(int id)
        {
            var item = shoesContext.Promos.Find(id);
            if (item != null)
            {
                shoesContext.Promos.Remove(item);
                shoesContext.SaveChanges();
            }
        }


        public List<Payment> GetAllPayments()
        {
            return shoesContext.Payments.ToList();
        }
        public Payment GetPayments(int id)
        {
            return shoesContext.Payments.Find(id);
        }

        public void AddPayments(Payment payment)
        {
            shoesContext.Payments.Add(payment);
            shoesContext.SaveChanges();
        }
        public void UpdatePayments(Payment payment)
        {
            var item = shoesContext.Payments.Find(payment.Payment_id);
            if (item != null)
            {
                shoesContext.Entry(item).CurrentValues.SetValues(payment);
                shoesContext.SaveChanges();
            }

        }
        public void DeletePayments(int id)
        {
            var item = shoesContext.Payments.Find(id);
            if (item != null)
            {
                shoesContext.Payments.Remove(item);
                shoesContext.SaveChanges();
            }
        }


        public List<Model1> GetAllModels()
        {
            return shoesContext.Models.ToList();
        }
        public Model1 GetModels(int id)
        {
            return shoesContext.Models.Find(id);
        }

        public void AddModels(Model1 model)
        {
            shoesContext.Models.Add(model);
            shoesContext.SaveChanges();
        }
        public void UpdateModels(Model1 model)
        {
            var item = shoesContext.Models.Find(model.Model_id);
            if (item != null)
            {
                shoesContext.Entry(item).CurrentValues.SetValues(model);
                shoesContext.SaveChanges();
            }

        }
        public void DeleteModels(int id)
        {
            var item = shoesContext.Models.Find(id);
            if (item != null)
            {
                shoesContext.Models.Remove(item);
                shoesContext.SaveChanges();
            }
        }


        public List<Shoe> GetAllNike()
        {
            return shoesContext.Shoes.ToList();
        }
        public Shoe GetNike(int id)
        {
            return shoesContext.Shoes.Find(id);
        }
       

        public void AddNike(Shoe nike)
        {
            shoesContext.Shoes.Add(nike);
            shoesContext.SaveChanges();
        }   
        public void UpdateNike(Shoe nike)
        {
            var item = shoesContext.Shoes.Find(nike.Model_id);
            if (item != null)
            {
                shoesContext.Entry(item).CurrentValues.SetValues(nike);
                shoesContext.SaveChanges();
            }

        }
        public void DeleteNike(int id)
        {
            var item = shoesContext.Shoes.Find(id);
            if( item != null)
            {
                shoesContext.Shoes.Remove(item);
                shoesContext.SaveChanges();
            }
        }

        
    }
}
