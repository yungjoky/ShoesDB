﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace upr1.Data.Model
{
    class Shipping
    {
        /// <summary>
        /// defining the objects we'll work with. Key tells us that the object under it is the primary key, required is that the field is required                                                               
        /// </summary>
        [Key]
        public int Shipping_id { get; set; }

        public DateTime? Creation_date { get; set; }
        [Required]
        public string Address { get; set; }
        [Required]
        public decimal Shipping_price { get; set; }

        [DefaultValue("DHL")]
        public string Delivery { get; set; }

        /// <summary>
        /// default value is used to make the default value of the "Delivery" field to "DHL"
        /// </summary>

        public virtual ICollection<Shoe> Shoes { get; set; }
       
        /// <summary>
        /// The connector between the type of a table and the table itself from the side of a foreign key
        /// </summary>
    }
}
