﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace upr1.Data.Model
{
    class Payment
    {
        /// <summary>
        /// defining the objects we'll work with. Key tells us that the object under it is the primary key, required is that the field is required                                                               
        /// </summary>
       
        [Key]
        public int Payment_id { get; set; }
        [Required]
        public string Payment_variant { get; set; }
        [Required]
        public string Currency { get; set; }

        public virtual ICollection<Shipping> Shippings { get; set; }


        /// <summary>
        /// The connector between the type of a table and the table itself from the side of a foreign key
        /// </summary>

    }
}
