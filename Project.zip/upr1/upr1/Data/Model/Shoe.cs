﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace upr1.Data.Model
{
   class Shoe
    {
        /// <summary>
        /// defining the objects we'll work with. Key tells us that the object under it is the primary key, required is that the field is required                                                               
        /// </summary>

        [Key]
        public int Shoe_id { get; set; }
        
        [Required]
        public string Shoe_name { get; set; }
        [Required]
        public double Size { get; set; }
        [Required]
        public decimal Price { get; set; }
        [Required]
        public string Material { get; set; }
        public double Rating { get; set; }

        [ForeignKey(nameof(Model))]
        public int Model_id { get; set; }
        [ForeignKey(nameof(Shipping))]
        public int Shipping_id { get; set; }
        /// <summary>
        /// foreign key is used as an identifier that the fields used under the foreign key definition are from another table.
        /// </summary>

        public virtual ICollection<Model1> Models { get; set; }
        public virtual ICollection<Shipping> Shippings { get; set; } 
        /// <summary>
        /// The connector between the type of a table and the table itself from the side of a foreign key
        /// </summary>


    }
}
