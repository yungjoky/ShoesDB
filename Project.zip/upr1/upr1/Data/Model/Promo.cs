﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace upr1.Data.Model
{
    class Promo
    {
        /// <summary>
        /// defining the objects we'll work with. Key tells us that the object under it is the primary key, required is that the field is required                                                               
        /// </summary>
        [Key]   
        public int Sale_id { get; set; }
        [Required]
        public int Percentage { get; set; }
        public DateTime? Promo_startdate { get; set; }
        [Required]
        public DateTime? Promo_enddate { get; set; }
        [ForeignKey(nameof(Shoe))]
        public int Shoe_id { get; set; }

        /// <summary>
        ///  The foreign key is used as an indentifier that the field (shoe_id in the current situation) is from another table.
        /// </summary>
        public virtual Shoe Shoe { get; set; }
        public virtual ICollection<Model1> Models { get; set; }

        /// <summary>
        /// The connector between the type of a table and the table itself from the side of a foreign key
        /// </summary>
    }
}
