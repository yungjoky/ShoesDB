﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using upr1.Data.Model;

namespace upr1.Data
{
    class ShoesContext : DbContext
    {
        public ShoesContext()
        {
            Database.EnsureCreated();
        }
        /// <summary>
        /// Ensuring that the database is created.
        /// </summary>
        public DbSet<Model1> Models { get; set; }
        public DbSet<Promo> Promos { get; set; }
        public DbSet<Shoe> Shoes { get; set; }
        public DbSet<Shipping> Shippings { get; set; }
        public DbSet<Payment> Payments { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
          
            var conn = "Data Source = (localdb)\\MSSQLLocalDB;Database = ShoesDB;Integrated Security=true;";
            optionsBuilder.UseSqlServer(conn);
        }
        
        /// <summary>
        /// Establishing connection with the database.
        /// </summary>


        }
}
