﻿using System;
using upr1.Display;

namespace upr1
{
    class Program
    {
        static void Main(string[] args)
        {
            Display1 display = new Display1();

            

        }
    }
}
