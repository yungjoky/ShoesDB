﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using upr1.Data.Model;
using upr1.Controller;
using System.Net.WebSockets;
using System.Runtime.InteropServices;
using System.Drawing;

namespace upr1.Display
{
    class Display1
    {
        public Display1()
        {
            MainInput();
        }

        /// <summary>
        /// Conneting the MainInput to the Display to make sure that it will run and show the menu after the program runs.
        /// </summary>

        ShoesController shoesctrl = new ShoesController();

        /// <summary>
        /// Creating an object from the shoescontroller class so we can use its methods.
        /// </summary>
        private void MainMenu()
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine(" ██╗    ██╗███████╗██╗      ██████╗ ██████╗ ███╗   ███╗███████╗");
            Console.WriteLine(" ██║    ██║██╔════╝██║     ██╔════╝██╔═══██╗████╗ ████║██╔════╝");
            Console.WriteLine(" ██║ █╗ ██║█████╗  ██║     ██║     ██║   ██║██╔████╔██║█████╗  ");
            Console.WriteLine(" ██║███╗██║██╔══╝  ██║     ██║     ██║   ██║██║╚██╔╝██║██╔══╝  ");
            Console.WriteLine(" ╚███╔███╔╝███████╗███████╗╚██████╗╚██████╔╝██║ ╚═╝ ██║███████╗");
            Console.WriteLine("  ╚══╝╚══╝ ╚══════╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝     ╚═╝╚══════╝");
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string('-', 18) + "MAIN" + new string('-', 18));
            Console.WriteLine(new string('-', 40));
            Console.WriteLine("1. CRUD for Model ");
            Console.WriteLine("2. CRUD for Shoes ");
            Console.WriteLine("3. CRUD for Payment ");
            Console.WriteLine("4. CRUD for Promo ");
            Console.WriteLine("5. CRUD for Shipping ");
            Console.WriteLine("6. List INFO about a Shoe");
            Console.WriteLine();
            Console.Write("Enter");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write(" '7'");
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(" to EXIT ");
            Console.WriteLine();
            
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("NOTE: CRUD -> CREATE, READ, UPDATE OR DELETE");
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.Write("> ");
            Console.ForegroundColor = ConsoleColor.Gray;

        }
        /// <summary>
        /// Creating the main menu also setting different colors that will be seen onscreen
        /// </summary>
        private void MainInput()
        {

            var operation = -1;
            do
            {
                MainMenu();
                operation = int.Parse(Console.ReadLine());

                switch (operation)
                {
                    case 1:
                        InputModels();
                        break;
                    case 2:
                        InputShoes();
                        break;
                    case 3:
                        InputPayments();
                        break;
                    case 4:
                        InputPromos();
                        break;

                    case 5:
                        InputShipping();
                        break;
                    case 6:
                        InfoShoes();
                        break;
                    default:
                        break;

                }
            } while (operation != 7);
        }
        /// <summary>
        /// Adding the main input so that the user is able to select one of the options that will be displayed in the main menu.
        /// 
        ///
        ///InfoShoes return the full info about the shoes in the database.
        ///</summary>
        private void InfoShoes()
        {
            
            List<Shipping> shipping = shoesctrl.GetAllShipping();
            List<Model1> model = shoesctrl.GetAllModels();
            List<Promo> promos = shoesctrl.GetAllPromo();
            List<Shoe> shoes = shoesctrl.GetAllNike();
            List<Payment> payment = shoesctrl.GetAllPayments();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string(' ', 16) + "SHIPPING" + new string(' ', 16));
            Console.WriteLine(new string('-', 40));
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine();
            Console.WriteLine();
            ListAllShippings();
            Console.WriteLine();
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string(' ', 16) + "MODELS" + new string(' ', 16));
            Console.WriteLine(new string('-', 40));
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine();
            Console.WriteLine();
            ListAllModels();
            Console.WriteLine();
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string(' ', 16) + "PROMO" + new string(' ', 16));
            Console.WriteLine(new string('-', 40));
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine();
            Console.WriteLine();
            ListAllPromos();
            Console.WriteLine();
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string(' ', 16) + "SHOES" + new string(' ', 16));
            Console.WriteLine(new string('-', 40));
            Console.ForegroundColor =  ConsoleColor.Gray;
            Console.WriteLine();
            Console.WriteLine();
            ListAllNike();
            Console.WriteLine();
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string(' ', 16) + "PAYMENT" + new string(' ', 16));
            Console.WriteLine(new string('-', 40));
            Console.ForegroundColor =  ConsoleColor.Gray;
            Console.WriteLine();
            Console.WriteLine();
            ListAllPayments();
            Console.WriteLine();
            Console.WriteLine();
        }


        /// <summary>
        /// Returns the shipping menu
        /// </summary>
        private void ShowMenuShipping()
        {
            Console.WriteLine(new string('-', 55));
            Console.WriteLine(new string('-', 9) + " ███████╗██╗  ██╗██╗██████╗ ██████╗ ██╗███╗   ██╗ ██████╗ " + new string('-', 9));
            Console.WriteLine(new string('-', 9) + " ██╔════╝██║  ██║██║██╔══██╗██╔══██╗██║████╗  ██║██╔════╝ " + new string('-', 9));
            Console.WriteLine(new string('-', 9) + " ███████╗███████║██║██████╔╝██████╔╝██║██╔██╗ ██║██║  ███╗" + new string('-', 9));
            Console.WriteLine(new string('-', 9) + " ╚════██║██╔══██║██║██╔═══╝ ██╔═══╝ ██║██║╚██╗██║██║   ██║" + new string('-', 9));
            Console.WriteLine(new string('-', 9) + " ███████║██║  ██║██║██║     ██║     ██║██║ ╚████║╚██████╔╝" + new string('-', 9));
            Console.WriteLine(new string('-', 9) + " ╚══════╝╚═╝  ╚═╝╚═╝╚═╝     ╚═╝     ╚═╝╚═╝  ╚═══╝ ╚═════╝ " + new string('-', 9));
            Console.WriteLine(new string('-', 55));
            Console.WriteLine("1. List all orders");
            Console.WriteLine("2. Add new orders");
            Console.WriteLine("3. Update orders");
            Console.WriteLine("4. Fetch orders");
            Console.WriteLine("5. Delete a orders by ID");
            Console.WriteLine("6. Exit");
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.Write("> ");
            Console.ForegroundColor = ConsoleColor.Gray;
        }
        /// <summary>
        /// Gives the user the ability to choose what he wants to do in the selected table.
        /// </summary>
        private void InputShipping()
        {
            var operation = -1;
            do
            {
                ShowMenuShipping();
                operation = int.Parse(Console.ReadLine());
                switch (operation)
                {
                    case 1:
                        ListAllShippings();
                        break;
                    case 2:
                        AddShippings();
                        break;
                    case 3:
                        UpdateShippings();
                        break;
                    case 4:
                        FetchShippings();
                        break;

                    case 5:
                        DeleteShippings();
                        break;
                    default:
                        break;


                }
            } while (operation != closeop);
        }

        private void DeleteShippings()
        {
            Console.Write("Enter ID to delete: ");
            int id = int.Parse(Console.ReadLine());
            shoesctrl.DeleteShipping(id);
            Console.WriteLine("Done.");
        }

        private void FetchShippings()
        {
            Console.Write("Enter ID to fetch: ");
            int id = int.Parse(Console.ReadLine());
            Shipping shipping = shoesctrl.GetShippings(id);
            if (shipping != null)
            {
                Console.WriteLine(new string('-', 40));
                Console.WriteLine("ID: " + shipping.Shipping_id);
                Console.WriteLine("Creation date: " + shipping.Creation_date);
                Console.WriteLine("Adress: " + shipping.Address);
                Console.WriteLine("Shipping price: " + shipping.Shipping_price);
                Console.WriteLine("Delivery: " + shipping.Delivery);
            }
        }

        private void UpdateShippings()
        {

            Console.Write("Enter ID to update: ");
            int id = int.Parse(Console.ReadLine());
            Shipping shipping = shoesctrl.GetShippings(id);
            if (shipping != null)
            {
                Console.WriteLine("What do you want to update? ");
                Console.WriteLine("1. Creation date");
                Console.WriteLine("2. Address");
                Console.WriteLine("3. Shipping price");
                Console.WriteLine("4. Delivery");
                Console.WriteLine("5. Exit");
                int command = -1;
                do
                {
                    Console.Write("Enter your selection: ");
                    command = int.Parse(Console.ReadLine());
                    switch (command)
                    {
                        case 1:
                            Console.WriteLine("Enter Creation date");
                            shipping.Creation_date = DateTime.Parse(Console.ReadLine());
                            break;
                        case 2:
                            Console.WriteLine("Enter Address");
                            shipping.Address = Console.ReadLine();
                            break;
                        case 3:
                            Console.WriteLine("Enter Shipping price");
                            shipping.Shipping_price = decimal.Parse(Console.ReadLine());
                            break;
                        case 4:
                            Console.WriteLine("Enter Delivery");
                            shipping.Delivery = Console.ReadLine();
                            break;
                        default:
                            
                            break;
                    }

                }
                while (command != 5);
                shoesctrl.UpdateShippings(shipping);
                
            }
            else
            {
                Console.WriteLine("SHIPPING NOT FOUND!");
            }


        }

        private void AddShippings()
        {
            Shipping shipping = new Shipping();

            Console.Write("Enter Creation date : ");
            shipping.Creation_date = DateTime.Parse(Console.ReadLine());
            Console.WriteLine("Enter Shipping price: ");
            shipping.Shipping_price = decimal.Parse(Console.ReadLine());
            Console.WriteLine("Enter address: ");
            shipping.Address = Console.ReadLine();
            Console.WriteLine("Enter Delivery: ");
            shipping.Delivery = Console.ReadLine();
            shoesctrl.AddShippings(shipping);

        }

        private void ListAllShippings()
        {
            
            var shipping = shoesctrl.GetAllShipping();

            int[] widths = { 15, 15, 23, 15,15 };
            Console.WriteLine("{0,-" + widths[0] + "} {1,-" + widths[1] + "} {2,-" + widths[2] + "} {3,-" + widths[3] + "} {4,-" + widths[4] +"}","ID", "Price", "Creation Date", "Adress", "Delivery");
            Console.WriteLine(new string('-', 80));
                foreach (var item in shipping)
                {
                    Console.WriteLine("{0,-" + widths[0] + "} {1,-" + widths[1] + "} {2,-" + widths[2] + "} {3,-" + widths[3] + "} {4,-" + widths[4] +"}", item.Shipping_id, item.Shipping_price, item.Creation_date, item.Address, item.Delivery);
                }
                Console.WriteLine(new string('-', 80));
           
        }
        /// <summary>
        /// Returns the promos menu
        /// </summary>
        private void ShowMenuPromos()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string('-', 18) + "PROMOS" + new string('-', 18));
            Console.WriteLine(new string('-', 40));
            Console.WriteLine("1. List all promos");
            Console.WriteLine("2. Add new promos");
            Console.WriteLine("3. Update promos");
            Console.WriteLine("4. Fetch promos");
            Console.WriteLine("5. Delete a promos by ID");
            Console.WriteLine("6. Exit");
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.Write("> ");
            Console.ForegroundColor = ConsoleColor.Gray;
        }
        /// <summary>
        /// Gives the user the ability to choose what he wants to do in the selected table.
        /// </summary>
        private void InputPromos()
        {
            var operation = -1;
            do
            {
                ShowMenuPromos();
                operation = int.Parse(Console.ReadLine());
                switch (operation)
                {
                    case 1:
                        ListAllPromos();
                        break;
                    case 2:
                        AddPromos();
                        break;
                    case 3:
                        UpdatePromos();
                        break;
                    case 4:
                        FetchPromos();
                        break;

                    case 5:
                        DeletePromos();
                        break;
                    default:
                        break;


                }
            } while (operation != closeop);
        }

        private void DeletePromos()
        {
            Console.Write("Enter ID to delete: ");
            int id = int.Parse(Console.ReadLine());
            shoesctrl.DeletePromos(id);
            Console.WriteLine("Done.");
        }

        private void FetchPromos()
        {
            Console.Write("Enter ID to fetch: ");
            int id = int.Parse(Console.ReadLine());
            Promo promo = shoesctrl.GetPromos(id);
            if (promo != null)
            {
                Console.WriteLine(new string('-', 40));
                Console.WriteLine("ID: " + promo.Sale_id);
                Console.WriteLine("Percentage: " + promo.Percentage);
                Console.WriteLine("Startdate: " + promo.Promo_startdate);
                Console.WriteLine("Enddate: " + promo.Promo_enddate);
                Console.WriteLine();
            }
        }

        private void UpdatePromos()
        {
            Console.Write("Enter ID to update: ");
            int id = int.Parse(Console.ReadLine());
            Promo promo = shoesctrl.GetPromos(id);
            if (promo != null)
            {
                Console.WriteLine("What do you want to update? ");
                Console.WriteLine("1. Percentage of the sale");
                Console.WriteLine("2. Start date");
                Console.WriteLine("3. End Date");
                Console.WriteLine("4. Shoe ID");
                int command = -1;
                do
                {
                    Console.Write("Enter your selection: ");
                    command = int.Parse(Console.ReadLine());
                    switch (command)
                    {
                        case 1:
                            Console.WriteLine("Enter Percentage of the sale");
                            promo.Percentage = int.Parse(Console.ReadLine());
                            break;
                        case 2:
                            Console.WriteLine("Enter Start date");
                            promo.Promo_startdate = DateTime.Parse(Console.ReadLine());
                            break;
                        case 3:
                            Console.WriteLine("Enter Price");
                            promo.Promo_enddate = DateTime.Parse(Console.ReadLine());
                            break;
                        case 4:
                            Console.WriteLine("Enter Shoe ID ");
                            promo.Shoe_id = int.Parse(Console.ReadLine());
                            break;
                        default:
                            break;
                    }

                }
                while (command != 5);
                shoesctrl.UpdatePromos(promo);
            }
            else
            {
                Console.WriteLine("PROMO NOT FOUND!");
            }
        }

        private void AddPromos()
        {
            Promo promo = new Promo();

            Console.Write("Enter  Percentage of the sale : ");
            promo.Percentage = int.Parse(Console.ReadLine());
            Console.Write("Enter start date of the sale : ");
            promo.Promo_startdate = DateTime.Parse( Console.ReadLine());
            Console.WriteLine("Enter end date of the sale: ");
            promo.Promo_enddate = DateTime.Parse(Console.ReadLine());
            Console.WriteLine("Enter Shoe id of the sale: ");
            promo.Shoe_id = int.Parse(Console.ReadLine());
            shoesctrl.AddPromos(promo);
        }

        private void ListAllPromos()
        {
            var promos = shoesctrl.GetAllPromo();
            int[] widths = { 10, 10, 20, 23, 15 };
            Console.WriteLine("{0,-" + widths[0] + "} {1,-" + widths[1] + "} {2,-" + widths[2] + "} {3,-" + widths[3] + "} {4,-" + widths[4] +"}", "Sale ID", "Percentage", "Start Date", "End Date", "Shoe ID");
            Console.WriteLine(new string('-', 80));
            foreach (var item in promos)
            {
                Console.WriteLine("{0,-" + widths[0] + "} {1,-" + widths[1] + "} {2,-" + widths[2] + "} {3,-" + widths[3] + "} {4,-" + widths[4] +"}", item.Sale_id, item.Percentage, item.Promo_startdate, item.Promo_enddate, item.Shoe_id);
            }
            Console.WriteLine(new string('-', 80));
        }
        /// <summary>
        /// Returns the payments menu
        /// </summary>
        private void ShowMenuPayments()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string('-', 18) + "PAYMENTS" + new string('-', 18));
            Console.WriteLine(new string('-', 40));
            Console.WriteLine("1. List all payments");
            Console.WriteLine("2. Add new payment");
            Console.WriteLine("3. Update payments");
            Console.WriteLine("4. Fetch payments");
            Console.WriteLine("5. Delete a payment by ID");
            Console.WriteLine("6. Exit");
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.Write("> ");
            Console.ForegroundColor = ConsoleColor.Gray;
        }
        /// <summary>
        /// Gives the user the ability to choose what he wants to do in the selected table.
        /// </summary>
        private void InputPayments()
        {
            var operation = -1;
            do
            {
                ShowMenuPayments();
                operation = int.Parse(Console.ReadLine());
                switch (operation)
                {
                    case 1:
                        ListAllPayments();
                        break;
                    case 2:
                        AddPayments();
                        break;
                    case 3:
                        UpdatePayments();
                        break;
                    case 4:
                        FetchPayments();
                        break;

                    case 5:
                        DeletePayments();
                        break;
                    default:
                        break;


                }
            } while (operation != closeop);
        }
        private void DeletePayments()
        {
            Console.Write("Enter ID to delete: ");
            int id = int.Parse(Console.ReadLine());
            shoesctrl.DeletePayments(id);
            Console.WriteLine("Done.");
        }
        private void FetchPayments()
        {
            Console.Write("Enter ID to fetch: ");
            int id = int.Parse(Console.ReadLine());
            Payment payment = shoesctrl.GetPayments(id);
            if (payment != null)
            {
                Console.WriteLine(new string('-', 40));
                Console.WriteLine("ID: " + payment.Payment_id);
                Console.WriteLine("Payment variant: " + payment.Payment_variant);
                Console.WriteLine("Currency" + payment.Currency);
            }
        }
        private void UpdatePayments()
        {
            Console.Write("Enter ID to update: ");
            int id = int.Parse(Console.ReadLine());
            Payment payment = shoesctrl.GetPayments(id);
            if (payment != null)
            {
                Console.WriteLine("What do you want to update? ");
                Console.WriteLine("1. Payment variant");
                Console.WriteLine("2. Payment currency");
                Console.WriteLine("3. Exit");
                int command = -1;
                do
                {
                    Console.Write("Enter your selection: ");
                    command = int.Parse(Console.ReadLine());
                    switch (command)
                    {
                        case 1:
                            Console.WriteLine("Enter Payment variant ");
                            payment.Payment_variant = Console.ReadLine();
                            break;
                        case 2:
                            Console.WriteLine("Enter Payment currency");
                            payment.Currency = Console.ReadLine();  
                            break;
                        default:
                            break;
                    }
                }
                while (command != 3);
                shoesctrl.UpdatePayments(payment);
            }
            else
            {
                Console.WriteLine("PAYMENT NOT FOUND!");
            }
        }
        private void AddPayments()
        {

            Payment payment = new Payment();
            
            Console.Write("Enter payment variant: ");
            payment.Payment_variant = Console.ReadLine();
            Console.Write("Enter payment currency: ");
            payment.Currency = Console.ReadLine();

            shoesctrl.AddPayments(payment);
        }
        private void ListAllPayments()
        {
            var payments = shoesctrl.GetAllPayments();
            var promos = shoesctrl.GetAllPromo();
            int[] widths = { 15, 15, 15};
            Console.WriteLine("{0,-" + widths[0] + "} {1,-" + widths[1] + "} {2,-" + widths[2] + "}", "ID", "Variant", "Currency");
            Console.WriteLine(new string('-', 80));
            foreach (var item in payments)
            {

                Console.WriteLine("{0,-" + widths[0] + "} {1,-" + widths[1] + "} {2,-" + widths[2] + "}", item.Payment_id, item.Payment_variant, item.Currency);
            }
            Console.WriteLine(new string('-', 80));
        }
        /// <summary>
        /// Returns the models menu
        /// </summary>
        private void ShowMenuModels()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string('-', 18) + "MENU" + new string('-', 18));
            Console.WriteLine(new string('-', 40));
            Console.WriteLine("1. List all models");
            Console.WriteLine("2. Add new model");
            Console.WriteLine("3. Update models");
            Console.WriteLine("4. Fetch models");
            Console.WriteLine("5. Delete a model by ID");
            Console.WriteLine("6. Exit");
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.Write("> ");
            Console.ForegroundColor = ConsoleColor.Gray;
        }
        /// <summary>
        /// Returns the Shoes menu
        /// </summary>
        private void ShowMenuShoes()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string('-', 18) + "MENU" + new string('-', 18));
            Console.WriteLine(new string('-', 40));
            Console.WriteLine("1. List all shoes");
            Console.WriteLine("2. Add new shoe");
            Console.WriteLine("3. Update shoes");
            Console.WriteLine("4. Fetch");
            Console.WriteLine("5. Delete shoe by ID");
            Console.WriteLine("6. Exit");
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.Write("> ");
            Console.ForegroundColor = ConsoleColor.Gray;
        }
        /// <summary>
        /// Gives the user the ability to choose what he wants to do in the selected table.
        /// </summary>
        private void InputModels()
        { 
             var operation = -1;
            do
            {
                ShowMenuModels();
        operation = int.Parse(Console.ReadLine());
                switch (operation)
                {
                    case 1:
                        ListAllModels();
                        break;
                    case 2:
                        AddModel();
                        break;
                    case 3:
                        UpdateModel();
                        break;
                    case 4:
                        FetchModel();
                        break;

                    case 5:
                        DeleteModel();
                        break;
                    default:
                        break;


                }
            } while (operation != closeop) ;
        }
        /// <summary>
        /// Gives the user the ability to choose what he wants to do in the selected table.
        /// </summary>
        private void InputShoes()
        {
            var operation = -1;
            do
            {
                ShowMenuShoes();
                operation = int.Parse(Console.ReadLine());
                switch (operation)
                {
                    case 1:
                        ListAllNike();
                        break;
                    case 2:
                        AddNike();
                        break;
                    case 3:
                        UpdateNike();
                        break;
                    case 4:
                        FetchNike();
                        break;

                    case 5:
                        DeleteNike();
                        break;
                    default:
                        break;


                }
            } while (operation != closeop);
        }
        private void DeleteModel()
        {
            Console.Write("Enter ID to delete: ");
            int id = int.Parse(Console.ReadLine());
            shoesctrl.DeleteModels(id);
            Console.WriteLine("Done.");
        }
        private void FetchModel()
        {
            Console.Write("Enter ID to fetch: ");
            int id = int.Parse(Console.ReadLine());
            Model1 model = shoesctrl.GetModels(id);
            if (model != null)
            {
                Console.WriteLine(new string('-', 40));
                Console.WriteLine("ID: " + model.Model_id);
                Console.WriteLine("Name: " + model.Model_name);
                Console.WriteLine("Size" + model.Description);
            }
        }
            private void UpdateModel()
            {
                Console.Write("Enter ID to update: ");
                int id = int.Parse(Console.ReadLine());
                Model1 model = shoesctrl.GetModels(id);
                if (model != null)
                {
                Console.WriteLine("What do you want to update? ");
                Console.WriteLine("1. Model Name");
                Console.WriteLine("2. Model description");
                Console.WriteLine("3. Exit");
                int command = -1;
                do
                {
                    Console.Write("Enter your selection: ");
                    command = int.Parse(Console.ReadLine());
                    switch (command)
                    {
                        case 1:
                            Console.WriteLine("Enter Model name");
                            model.Model_name = Console.ReadLine();
                            break;
                        case 2:
                            Console.WriteLine("Enter Description");
                            model.Description = Console.ReadLine();
                            break;
                        default:
                            break;
                    }

                }
                while (command != 3);
                shoesctrl.UpdateModels(model);

                }
                else
                {
                    Console.WriteLine("MODEL NOT FOUND!");
                }
            }
            private void AddModel()
            {
                Model1 model = new Model1();
                Console.Write("Enter model name: ");
                model.Model_name = Console.ReadLine();
                Console.Write("Enter Description: ");
                model.Description = Console.ReadLine();
                
                shoesctrl.AddModels(model);

            }
        private void ListAllModels()
        {
            
            var models = shoesctrl.GetAllModels();
            int[] widths = { 15, 15, 15 };
            Console.WriteLine("{0,-" + widths[0] + "} {1,-" + widths[1] + "} {2,-" + widths[2] + "}", "ID", "Name", "Decription");
            Console.WriteLine(new string('-', 80));
            foreach (var item in models)
            {

                Console.WriteLine("{0,-" + widths[0] + "} {1,-" + widths[1] + "} {2,-" + widths[2] + "}", item.Model_id, item.Model_name, item.Description);
            }
            Console.WriteLine(new string('-', 80));
        }
        private void FetchNike()
        {
            Console.Write("Enter ID to fetch: ");
            int id = int.Parse(Console.ReadLine());
            Shoe nike = shoesctrl.GetNike(id);
            if (nike != null)
            {
                Console.WriteLine(new string('-',40));
                Console.WriteLine("ID: " + nike.Shoe_id);
                Console.WriteLine("Name: " + nike.Shoe_name);
                Console.WriteLine("Size" + nike.Size);
                Console.WriteLine("Price"+ nike.Price);
                Console.WriteLine("Material" + nike.Material);
                Console.WriteLine("Rating" + nike.Rating);
            }
        }
        private void AddNike()
        {
            Shoe nike = new Shoe();
            Console.Write("Enter Shoes name: ");
            nike.Shoe_name = Console.ReadLine();
            Console.Write("Enter Size: ");
            nike.Size = double.Parse(Console.ReadLine());
            Console.Write("Enter Price: ");
            nike.Price = decimal.Parse(Console.ReadLine());
            Console.Write("Enter Material: ");
            nike.Material = Console.ReadLine();
            Console.Write("Enter Rating: ");
            nike.Rating = double.Parse(Console.ReadLine());
            shoesctrl.AddNike(nike);  
        }
        private void DeleteNike()
        {

            Console.Write("Enter ID to delete: ");
            int id = int.Parse(Console.ReadLine());
            shoesctrl.DeleteNike(id);
            Console.WriteLine("Done.");
        }
        private void UpdateNike()
        {
            Console.Write("Enter ID to update: ");
            int id = int.Parse(Console.ReadLine());
            Shoe nike = shoesctrl.GetNike(id);

            if(nike != null)
            {
                Console.WriteLine("What do you want to update? ");
                Console.WriteLine("1. Shoes name");
                Console.WriteLine("2. Size");
                Console.WriteLine("3. Price");
                Console.WriteLine("4. Material");
                Console.WriteLine("5. Rating");
                Console.WriteLine("6. Exit");
                int command = -1;
                do
                {
                    Console.Write("Enter your selection: ");
                    command = int.Parse(Console.ReadLine());
                    switch (command)
                    {
                        case 1:
                            Console.WriteLine("Enter Shoes name");
                            nike.Shoe_name = Console.ReadLine();
                            break;
                        case 2:
                            Console.WriteLine("Enter Size");
                           nike.Size = double.Parse(Console.ReadLine());
                            break;
                        case 3:
                            Console.WriteLine("Enter Price");
                            nike.Price = decimal.Parse(Console.ReadLine());
                            break;
                        case 4:
                            Console.WriteLine("Enter Material");
                            nike.Material = Console.ReadLine();
                            break;
                        case 5:
                            Console.WriteLine("Enter Rating");
                            nike.Rating = double.Parse(Console.ReadLine());
                            break;
                        default:

                            break;
                    }
                }
                while (command != 6);
                shoesctrl.UpdateNike(nike);
            }
            else
            {
                Console.WriteLine("SHOE NOT FOUND!");
            }
        }
        private void ListAllNike()
        {
            
            var shoes = shoesctrl.GetAllNike();
            int[] widths = { 15, 15, 15, 15, 15, 15 };
            Console.WriteLine("{0,-" + widths[0] + "} {1,-" + widths[1] + "} {2,-" + widths[2] + "} {3,-" + widths[3] + "} {4,-" + widths[4] + "} {5,-" + widths[5] + "}", "ID", "Name", "Size", "Price", "Material", "Rating");
            Console.WriteLine(new string('-', 80));
            foreach (var item in shoes)
            {
                Console.WriteLine("{0,-" + widths[0] + "} {1,-" + widths[1] + "} {2,-" + widths[2] + "} {3,-" + widths[3] + "}  {4,-" + widths[4] + "}  {5,-" + widths[5] + "}", item.Shoe_id, item.Shoe_name, item.Size,item.Price,item.Material,item.Rating);
            }
            Console.WriteLine(new string('-', 80));
        }
        private int closeop = 
            6;
    }
}
